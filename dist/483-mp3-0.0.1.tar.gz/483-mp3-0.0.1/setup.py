#!/usr/bin/env python

from distutils.core import setup

setup(name='483-mp3',
      version='0.0.1',
      description='Link state and distance vector routing protocols',
      url='https://github.com/hkiang01/438-mp3',
      py_modules=['routing'],
      )
